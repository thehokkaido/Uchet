﻿using System;
using System.Windows;
using System.Windows.Input;
using Uchet.Models;

namespace Uchet.Views.Admin
{
    public partial class AddEditUserWindow : Window
    {
        public Uchet.Models.User ResultUser { get; private set; }

        public AddEditUserWindow()
        {
            InitializeComponent();
            cmbRole.ItemsSource = new List<string> { "User", "Admin" };
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Password;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Заполните все поля");
                return;
            }

            var user = new Uchet.Models.User
            {
                Username = username,
                Password = password,
                Role = cmbRole.SelectedItem as string
            };

            using var context = new Data.AppDbContext();
            context.Users.Add(user);
            context.SaveChanges();

            ResultUser = user;
            DialogResult = true;
            Close();
        }

        private void txtUsername_GotFocus(object sender, RoutedEventArgs e)
        {
            if (txtUsername.Text == "")
            {
                txtUsernamePlaceholder.Visibility = Visibility.Collapsed;
            }
        }

        private void txtUsername_LostFocus(object sender, RoutedEventArgs e)
        {
            if (txtUsername.Text == "")
            {
                txtUsernamePlaceholder.Visibility = Visibility.Visible;
            }
        }

        private void txtUsernamePlaceholder_MouseDown(object sender, MouseButtonEventArgs e)
        {
            txtUsername.Focus();
        }


        private void txtPassword_GotFocus(object sender, RoutedEventArgs e)
        {
            if (txtPassword.Password == "")
            {
                txtPasswordPlaceholder.Visibility = Visibility.Collapsed;
            }
        }

        private void txtPassword_LostFocus(object sender, RoutedEventArgs e)
        {
            if (txtPassword.Password == "")
            {
                txtPasswordPlaceholder.Visibility = Visibility.Visible;
            }
        }

        private void txtPasswordPlaceholder_MouseDown(object sender, MouseButtonEventArgs e)
        {
            txtPassword.Focus();
        }
    }
}