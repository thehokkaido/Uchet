﻿using System;
using System.Collections.Generic;
using System.Windows;
using Uchet.Data;
using Uchet.Helpers;
using Uchet.Models;
using Task = Uchet.Models.Task;

namespace Uchet.Views.User
{
    public partial class UserMainWindow : Window
    {
        private readonly AppDbContext _context = new();

        public UserMainWindow()
        {
            InitializeComponent();
            LoadTasks();
        }

        private void LoadTasks()
        {
            dgTasks.ItemsSource = _context.Tasks.ToList();
        }

        private void BtnAddTask_Click(object sender, RoutedEventArgs e)
        {
            var window = new AddEditTaskWindow();
            if (window.ShowDialog() == true)
            {
                LoadTasks();
            }
        }

        private void DeleteTask_Click(object sender, RoutedEventArgs e)
        {
            if (dgTasks.SelectedItem is Task task)
            {
                var result = MessageBox.Show($"Удалить задачу \"{task.Title}\"?", "Подтверждение", MessageBoxButton.YesNo);
                if (result == MessageBoxResult.Yes)
                {
                    _context.Tasks.Remove(task);
                    _context.SaveChanges();
                    LoadTasks();
                }
            }
        }

        private void EditTask_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as System.Windows.Controls.Button;
            var task = button?.DataContext as Task;

            if (task != null)
            {
                var window = new AddEditTaskWindow(task);
                if (window.ShowDialog() == true)
                {
                    task.Title = window.txtTitle.Text;
                    task.Description = window.txtDescription.Text;
                    task.Priority = window.cmbPriority.SelectedItem as string;

                    task.Deadline = window.dpDeadline.SelectedDate?.WithKind(DateTimeKind.Utc);
                    task.Reminder = window.dpReminder.SelectedDate?.WithKind(DateTimeKind.Utc);

                    using var context = new Data.AppDbContext();
                    context.Tasks.Update(task);

                    try
                    {
                        context.SaveChanges();
                        LoadTasks();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при сохранении: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }
        private void OpenKanban_Click(object sender, RoutedEventArgs e)
        {
            var kanban = new KanbanBoardWindow();
            kanban.Show();
        }
    }
}