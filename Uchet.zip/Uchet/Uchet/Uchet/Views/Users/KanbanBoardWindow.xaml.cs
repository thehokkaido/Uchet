﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Uchet.Data;
using Uchet.Models;

namespace Uchet.Views.User
{
    public partial class KanbanBoardWindow : Window
    {
        private readonly AppDbContext _context = new();
        private Uchet.Models.Task _draggedTask;

        public KanbanBoardWindow()
        {
            InitializeComponent();
            LoadTasks();    
        }

        private void LoadTasks()
        {
            var allTasks = _context.Tasks.ToList();

            lstNewTasks.ItemsSource = allTasks.Where(t => !t.IsCompleted).ToList();
            lstCompletedTasks.ItemsSource = allTasks.Where(t => t.IsCompleted).ToList();

            lstInProgressTasks.ItemsSource = new List<Uchet.Models.Task>();
        }

        private void Task_PreviewMouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            var border = sender as Border;
            _draggedTask = border?.DataContext as Uchet.Models.Task;
            if (_draggedTask != null)
            {
                DragDrop.DoDragDrop(border, _draggedTask, DragDropEffects.Move);
            }
        }

        private void Task_DragEnter(object sender, DragEventArgs e)
        {
            e.Effects = DragDropEffects.Move;
        }

        private void Task_Drop(object sender, DragEventArgs e)
        {
            if (_draggedTask == null || e.Data.GetDataPresent(typeof(Uchet.Models.Task)) is false)
                return;

            var targetList = sender as ItemsControl;
            if (targetList == null) return;

            switch (targetList.Name)
            {
                case "lstNewTasks":
                    _draggedTask.IsCompleted = false;
                    break;
                case "lstCompletedTasks":
                    _draggedTask.IsCompleted = true;
                    break;
                default:
                    _draggedTask.IsCompleted = false;
                    break;
            }

            using var context = new AppDbContext();
            context.Tasks.Update(_draggedTask);
            context.SaveChanges();

            LoadTasks();
        }
    }
}