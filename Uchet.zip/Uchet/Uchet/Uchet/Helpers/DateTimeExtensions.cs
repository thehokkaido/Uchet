﻿using System;

namespace Uchet.Helpers
{
    public static class DateTimeExtensions
    {

        public static DateTime? WithKind(this DateTime? value, DateTimeKind kind)
        {
            if (!value.HasValue) return null;
            return value.Value.WithKind(kind);
        }

        public static DateTime WithKind(this DateTime value, DateTimeKind kind)
        {
            if (value.Kind == kind) return value;
            return DateTime.SpecifyKind(value, kind);
        }
    }
}