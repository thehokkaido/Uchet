﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Uchet.Models
{
    [Table("tasks")]
    public class Task
    {
        [Column("id")]
        public int Id { get; set; }

        [Column("title")]
        public string Title { get; set; }

        [Column("description")]
        public string Description { get; set; }

        [Column("priority")]
        public string Priority { get; set; } // Low, Medium, High

        [Column("deadline")]
        public DateTime? Deadline { get; set; }

        [Column("reminder")]
        public DateTime? Reminder { get; set; }

        [Column("is_completed")]
        public bool IsCompleted { get; set; }
    }
}