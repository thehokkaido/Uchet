﻿using System.Collections.Generic;
using System.Windows;
using Uchet.Data;
using Uchet.Models;

namespace Uchet.Views.Admin
{
    public partial class AdminPanelWindow : Window
    {
        private readonly AppDbContext _context = new();
        private List<Uchet.Models.User> Users { get; set; }

        public List<string> Roles => new() { "User", "Admin" };

        public AdminPanelWindow()
        {
            InitializeComponent();  
            DataContext = this;
            LoadUsers();
        }

        private void LoadUsers()
        {
            Users = _context.Users.ToList();
            dgUsers.ItemsSource = Users;
        }

        private void DeleteUser_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as System.Windows.Controls.Button;

            var user = button?.DataContext as Uchet.Models.User;

            if (user != null)
            {
                var result = MessageBox.Show($"Удалить пользователя {user.Username}?", "Подтверждение", MessageBoxButton.YesNo);
                if (result == MessageBoxResult.Yes)
                {
                    _context.Users.Remove(user);
                    _context.SaveChanges();
                    LoadUsers();
                }
            }
        }

        private void cmbRole_Loaded(object sender, RoutedEventArgs e)
        {
            var combo = sender as System.Windows.Controls.ComboBox;
            combo.ItemsSource = new List<string> { "User", "Admin" };
        }

        private void dgUsers_RowEditEnding(object sender, System.Windows.Controls.DataGridRowEditEndingEventArgs e)
        {
            if (e.Row.Item is Uchet.Models.User editedUser)
            {
                _context.Users.Update(editedUser);
                _context.SaveChanges();
            }
        }
    }
}