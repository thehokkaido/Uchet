﻿using System;
using System.Windows;
using System.Windows.Input;
using Uchet.Data;
using Uchet.Models;
using Task = Uchet.Models.Task;
using Uchet.Helpers;

namespace Uchet.Views.User
{
    public partial class AddEditTaskWindow : Window
    {
        public Task ResultTask { get; private set; }

        public AddEditTaskWindow()
        {
            InitializeComponent();
            cmbPriority.ItemsSource = new List<string> { "Low", "Medium", "High" };
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTitle.Text))
            {
                MessageBox.Show("Введите название задачи");
                return;
            }

            var task = new Task
            {
                Title = txtTitle.Text,
                Description = txtDescription.Text,
                Priority = cmbPriority.SelectedItem as string,
                Deadline = dpDeadline.SelectedDate?.WithKind(DateTimeKind.Utc),
                Reminder = dpReminder.SelectedDate?.WithKind(DateTimeKind.Utc),
                IsCompleted = false
            };

            using var context = new AppDbContext();
            context.Tasks.Add(task);

            try
            {
                context.SaveChanges();
                ResultTask = task;
                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void txtTitle_GotFocus(object sender, RoutedEventArgs e)
        {
            if (txtTitle.Text == "")
            {
                txtTitlePlaceholder.Visibility = Visibility.Collapsed;
            }
        }

        private void txtTitle_LostFocus(object sender, RoutedEventArgs e)
        {
            if (txtTitle.Text == "")
            {
                txtTitlePlaceholder.Visibility = Visibility.Visible;
            }
        }

        private void txtTitlePlaceholder_MouseDown(object sender, MouseButtonEventArgs e)
        {
            txtTitle.Focus();
        }

        private void txtDescription_GotFocus(object sender, RoutedEventArgs e)
        {
            if (txtDescription.Text == "")
            {
                txtDescriptionPlaceholder.Visibility = Visibility.Collapsed;
            }
        }

        private void txtDescription_LostFocus(object sender, RoutedEventArgs e)
        {
            if (txtDescription.Text == "")
            {
                txtDescriptionPlaceholder.Visibility = Visibility.Visible;
            }
        }

        private void txtDescriptionPlaceholder_MouseDown(object sender, MouseButtonEventArgs e)
        {
            txtDescription.Focus();
        }
    }
}