﻿using System;
using System.Collections.Generic;
using System.Windows;
using Uchet.Data;
using Uchet.Models;
using Task = Uchet.Models.Task;

namespace Uchet.Views.User
{
    public partial class UserMainWindow : Window
    {
        private readonly AppDbContext _context = new();

        public UserMainWindow()
        {
            InitializeComponent();
            LoadTasks();
        }

        private void LoadTasks()
        {
            dgTasks.ItemsSource = _context.Tasks.ToList();
        }

        private void BtnAddTask_Click(object sender, RoutedEventArgs e)
        {
            var window = new AddEditTaskWindow();
            if (window.ShowDialog() == true)
            {
                LoadTasks();
            }
        }

        private void DeleteTask_Click(object sender, RoutedEventArgs e)
        {
            if (dgTasks.SelectedItem is Task task)
            {
                var result = MessageBox.Show($"Удалить задачу \"{task.Title}\"?", "Подтверждение", MessageBoxButton.YesNo);
                if (result == MessageBoxResult.Yes)
                {
                    _context.Tasks.Remove(task);
                    _context.SaveChanges();
                    LoadTasks();
                }
            }
        }
    }
}