﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Linq;
using System.Security.Cryptography;
using Uchet.Data;
using Uchet.Models;
using Microsoft.EntityFrameworkCore;

namespace Uchet.Views
{
    public partial class LoginWindow : Window
    {
        private readonly AppDbContext _context = new();

        public LoginWindow()
        {
            InitializeComponent();

        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            var username = txtUsername.Text;
            var password = txtPassword.Password;

            var user = _context.Users.FirstOrDefault(u => u.Username == username);

            if (user != null && user.Password == password)
            {
                if (user.Role == "Admin")
                {
                    var adminPanel = new Views.Admin.AdminPanelWindow();
                    adminPanel.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Вы вошли как пользователь.");
                }
            }
            else
            {
                txtError.Text = "Неверный логин или пароль";
                txtError.Visibility = Visibility.Visible;
            }
        }

        private void txtUsername_GotFocus(object sender, RoutedEventArgs e)
        {
            if (txtUsername.Text == "")
            {
                txtUsernamePlaceholder.Visibility = Visibility.Collapsed;
            }
        }

        private void txtUsername_LostFocus(object sender, RoutedEventArgs e)
        {
            if (txtUsername.Text == "")
            {
                txtUsernamePlaceholder.Visibility = Visibility.Visible;
            }
        }

        private void txtPassword_GotFocus(object sender, RoutedEventArgs e)
        {
            if (txtPassword.Password == "")
            {
                txtPasswordPlaceholder.Visibility = Visibility.Collapsed;
            }
        }

        private void txtPassword_LostFocus(object sender, RoutedEventArgs e)
        {
            if (txtPassword.Password == "")
            {
                txtPasswordPlaceholder.Visibility = Visibility.Visible;
            }
        }

        private void txtUsernamePlaceholder_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            txtUsername.Focus();
        }

        private void txtPasswordPlaceholder_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            txtPassword.Focus();
        }

    }
}
